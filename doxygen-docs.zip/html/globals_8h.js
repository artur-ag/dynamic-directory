var globals_8h =
[
    [ "FindMode", "globals_8h.html#ab55357cbf21a8cfaeb8e63b118b39c0c", [
      [ "FindForFind", "globals_8h.html#ab55357cbf21a8cfaeb8e63b118b39c0caed8e7a3fbf2284ce7539a0433698fa5b", null ],
      [ "FindForConnect", "globals_8h.html#ab55357cbf21a8cfaeb8e63b118b39c0ca41de00857291e5b368b39e58c729dd26", null ]
    ] ],
    [ "FindStatus", "globals_8h.html#aad64cfc1afdcfdd66cd84751351519a4", [
      [ "NotFinding", "globals_8h.html#aad64cfc1afdcfdd66cd84751351519a4a011ce6c46ed3f4bc6ca74ee3b502303f", null ],
      [ "WaitForFW", "globals_8h.html#aad64cfc1afdcfdd66cd84751351519a4a2cd36828a7d5e1109ac6aa07a9d4a07a", null ],
      [ "WaitForRPL", "globals_8h.html#aad64cfc1afdcfdd66cd84751351519a4a0fe33d9429017f82be251458b8ea6803", null ]
    ] ],
    [ "JoinStatus", "globals_8h.html#a66bf92a169598cb896dcb1c669406075", [
      [ "NotJoined", "globals_8h.html#a66bf92a169598cb896dcb1c669406075a3f9af8ff350c8ca2697f93fec226108d", null ],
      [ "WaitForDNS", "globals_8h.html#a66bf92a169598cb896dcb1c669406075afd4780e501442046e30093a286816667", null ],
      [ "WaitForLST", "globals_8h.html#a66bf92a169598cb896dcb1c669406075a11a037f793cc3bbbf9db34d480b9332e", null ],
      [ "WaitForOK", "globals_8h.html#a66bf92a169598cb896dcb1c669406075a9dcd841fda069c5e665f69dbbf6d8b09", null ],
      [ "Joined", "globals_8h.html#a66bf92a169598cb896dcb1c669406075a46c8473c20dee3a0c0cd09ffb324aee3", null ],
      [ "LeavingDNS", "globals_8h.html#a66bf92a169598cb896dcb1c669406075ad5c333880b67fc2bca753b4da534ff85", null ],
      [ "LeavingUsers", "globals_8h.html#a66bf92a169598cb896dcb1c669406075a3d47930a1c2d1d9975ed8d2534f6e25e", null ],
      [ "SearchingNewDns", "globals_8h.html#a66bf92a169598cb896dcb1c669406075aff335aa9721ef8f0cc16471458cb3fca", null ],
      [ "LeavingForGood", "globals_8h.html#a66bf92a169598cb896dcb1c669406075ac50b371c04f3918ff77ed7503ad3b19d", null ]
    ] ],
    [ "abortJoin", "globals_8h.html#ab528aacf1962cb5dad6a68dbcb429442", null ],
    [ "getNameServer", "globals_8h.html#a4bb99e92aa0269c20bdc1f1c09adad61", null ],
    [ "contacts", "globals_8h.html#a436665f391fd410cf78813a9361531c1", null ],
    [ "dnsSocket", "globals_8h.html#a2a7e0885d0b5749e64e1d66bb4d4be10", null ],
    [ "findMode", "globals_8h.html#aa7f1bd4be586bcab01881e565f1f6745", null ],
    [ "findStatus", "globals_8h.html#a71b2637efd8c6940845d4dfcc4c9ea7a", null ],
    [ "joinStatus", "globals_8h.html#a347e0d1642069ab73d2c9e5e853515f9", null ],
    [ "myDnsPort", "globals_8h.html#a7e489fe731cbea399dcf01948708c486", null ],
    [ "myIP", "globals_8h.html#a273bd63b50aa6977e43febcb2f4d3518", null ],
    [ "myName", "globals_8h.html#ad0ccbea96f9e289b254d540802cc4df0", null ],
    [ "myTalkPort", "globals_8h.html#a8fe0901d911d2d25b8b80cf9fddc7bd8", null ],
    [ "nameServer", "globals_8h.html#a410195894e5d9e5ee478037870529097", null ],
    [ "nameToFind", "globals_8h.html#a3a79f9a3b7ff57562819685406c5f42e", null ],
    [ "oksExpected", "globals_8h.html#ae06ee2da9ed1b2550f3330dca519812a", null ],
    [ "saAddr", "globals_8h.html#a9df294c17ce9ba529ba02a75427b832c", null ],
    [ "saIP", "globals_8h.html#a334b9065ff9d98524f4f47ff5760ead4", null ],
    [ "saPort", "globals_8h.html#ad0991b8bced639ebf9ac0b0a1d3ddbae", null ],
    [ "talkServerSocket", "globals_8h.html#a968b2c5fbe0b2f5dbcef6459eb0449c1", null ],
    [ "talkSocket", "globals_8h.html#ab8cbf40b9361e9ead7965f7553214a2c", null ],
    [ "verbose", "globals_8h.html#a0b2caeb4b6f130be43e5a2f0267dd453", null ]
];