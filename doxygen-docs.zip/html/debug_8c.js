var debug_8c =
[
    [ "logm", "debug_8c.html#aa03fee8bc5f92b9e55715658969247cd", null ]
];