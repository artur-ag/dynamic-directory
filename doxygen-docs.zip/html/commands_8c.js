var commands_8c =
[
    [ "disconnect", "commands_8c.html#a960705de531a20389fb29928d43258c3", null ],
    [ "find", "commands_8c.html#a0a1b3d7712a9863a2b37b7fea88056b3", null ],
    [ "getRegMessage", "commands_8c.html#a3686c0352f2b82f22ff2d76f62ba2718", null ],
    [ "help", "commands_8c.html#a97ee70a8770dc30d06c744b24eb2fcfc", null ],
    [ "isServer", "commands_8c.html#a642dc09bc041fe347f35ea51713a5562", null ],
    [ "join", "commands_8c.html#a6c7abfff648dad193674fc432ad4840d", null ],
    [ "leave", "commands_8c.html#afe1abdb6d5a98b8e65cf99d2eb20112c", null ],
    [ "parseCommand", "commands_8c.html#ab5297c31f43bec78bf080e3d0806234c", null ],
    [ "printState", "commands_8c.html#a5aaf516d78b7caef2d2b9867b02542e7", null ],
    [ "rickroll", "commands_8c.html#a0b93e6a3ac7105977d863c5bd940f8fb", null ],
    [ "sendMessage", "commands_8c.html#a8bbf464384e4ff787fc006dcc38ccd6e", null ],
    [ "sendRawMessage", "commands_8c.html#aa50a95001a98c33cd0dbc0b3080f6aa0", null ],
    [ "errno", "commands_8c.html#ad65a8842cc674e3ddf69355898c0ecbf", null ]
];