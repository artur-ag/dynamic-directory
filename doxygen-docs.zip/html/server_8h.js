var server_8h =
[
    [ "acceptCall", "server_8h.html#a1fcddbd9172248eb40f25dcdc420f00e", null ],
    [ "becomeDNS", "server_8h.html#a96e2cbac33d799cf2f92cc7dfcacf371", null ],
    [ "continueFindFW", "server_8h.html#a60f33b1b778bb8db01df7db5c7406684", null ],
    [ "continueFindRPL", "server_8h.html#a797b37341e06b2aff10463b21bdd402f", null ],
    [ "continueJoin", "server_8h.html#a8c01918a0cdc1931e67f8aaf2d50984a", null ],
    [ "continueJoinOK", "server_8h.html#aac3c63f5574df1c654ca027266d2e484", null ],
    [ "continueLeave", "server_8h.html#a66b252e8ed65ab8a1e42d9a5aa319d64", null ],
    [ "getContactFromMsg", "server_8h.html#a8ae651c902e257d16f57159b8c3a5296", null ],
    [ "parseServerCommand", "server_8h.html#a7c3981ad3d51602c6243b7d7e52278f3", null ],
    [ "prepareTalkServer", "server_8h.html#ac341ee8d4763a832daca92465734da4a", null ],
    [ "receiveList", "server_8h.html#a45630fa5969b9ce97e10d7f77cdf63af", null ],
    [ "receiveMessage", "server_8h.html#a31876151b63941ae68830fd1527bc473", null ],
    [ "registerNewUser", "server_8h.html#a9538b34b4d35b859e063fa9ba4f89a40", null ],
    [ "replyToQuery", "server_8h.html#a958759938e44eef51de14017780e6488", null ],
    [ "startChatCall", "server_8h.html#a7351a900efbe3b9ef812e2a520826044", null ],
    [ "unregisterUser", "server_8h.html#ae07e9eb35e2cf804c3f0d67af2ca4e0f", null ]
];