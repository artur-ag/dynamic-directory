var files =
[
    [ "commands.c", "commands_8c.html", "commands_8c" ],
    [ "commands.h", "commands_8h.html", "commands_8h" ],
    [ "contact.h", "contact_8h.html", "contact_8h" ],
    [ "debug.c", "debug_8c.html", "debug_8c" ],
    [ "debug.h", "debug_8h.html", "debug_8h" ],
    [ "globals.c", "globals_8c.html", "globals_8c" ],
    [ "globals.h", "globals_8h.html", "globals_8h" ],
    [ "list.c", "list_8c.html", "list_8c" ],
    [ "list.h", "list_8h.html", "list_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "server.c", "server_8c.html", "server_8c" ],
    [ "server.h", "server_8h.html", "server_8h" ]
];