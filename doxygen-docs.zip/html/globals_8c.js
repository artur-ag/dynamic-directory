var globals_8c =
[
    [ "abortJoin", "globals_8c.html#ab528aacf1962cb5dad6a68dbcb429442", null ],
    [ "getNameServer", "globals_8c.html#a4bb99e92aa0269c20bdc1f1c09adad61", null ],
    [ "contacts", "globals_8c.html#a436665f391fd410cf78813a9361531c1", null ],
    [ "dnsSocket", "globals_8c.html#a2a7e0885d0b5749e64e1d66bb4d4be10", null ],
    [ "findMode", "globals_8c.html#aa7f1bd4be586bcab01881e565f1f6745", null ],
    [ "findStatus", "globals_8c.html#a71b2637efd8c6940845d4dfcc4c9ea7a", null ],
    [ "joinStatus", "globals_8c.html#a347e0d1642069ab73d2c9e5e853515f9", null ],
    [ "myDnsPort", "globals_8c.html#a7e489fe731cbea399dcf01948708c486", null ],
    [ "myIP", "globals_8c.html#a273bd63b50aa6977e43febcb2f4d3518", null ],
    [ "myName", "globals_8c.html#ad0ccbea96f9e289b254d540802cc4df0", null ],
    [ "myTalkPort", "globals_8c.html#a8fe0901d911d2d25b8b80cf9fddc7bd8", null ],
    [ "nameServer", "globals_8c.html#a410195894e5d9e5ee478037870529097", null ],
    [ "nameToFind", "globals_8c.html#a849ba520a0294c4598289e7744e394fb", null ],
    [ "oksExpected", "globals_8c.html#ae06ee2da9ed1b2550f3330dca519812a", null ],
    [ "saAddr", "globals_8c.html#a9df294c17ce9ba529ba02a75427b832c", null ],
    [ "saIP", "globals_8c.html#a334b9065ff9d98524f4f47ff5760ead4", null ],
    [ "saPort", "globals_8c.html#ad0991b8bced639ebf9ac0b0a1d3ddbae", null ],
    [ "talkServerSocket", "globals_8c.html#a968b2c5fbe0b2f5dbcef6459eb0449c1", null ],
    [ "talkSocket", "globals_8c.html#ab8cbf40b9361e9ead7965f7553214a2c", null ],
    [ "verbose", "globals_8c.html#a0b2caeb4b6f130be43e5a2f0267dd453", null ]
];