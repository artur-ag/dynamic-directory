var struct_contact =
[
    [ "dnsAddr", "struct_contact.html#a3e5b283d7a0d10c7fccb0814e983a83a", null ],
    [ "dnsPort", "struct_contact.html#aea2f9dd57472d7779591f1b1e97253a3", null ],
    [ "ip", "struct_contact.html#ac0e42f432a3ee5cac220b24a4dcc975d", null ],
    [ "name", "struct_contact.html#a4f4ce0a89bfc6e0c29787faf7de3bfcd", null ],
    [ "okExpected", "struct_contact.html#a6efde4258e3fa3975d3bc302f1e43d8d", null ],
    [ "talkPort", "struct_contact.html#ae2538c4adbf6d1ab3bdb2870db4850b5", null ]
];