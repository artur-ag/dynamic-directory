var list_8c =
[
    [ "add", "list_8c.html#a11ac98f2e01e7fa68bdb69f760fe41be", null ],
    [ "emptyList", "list_8c.html#abd0aee2995c30006ca350371a713dee7", null ],
    [ "get", "list_8c.html#aff4f19e720f6e0cb808e2a0af5af43cb", null ],
    [ "getByAddr", "list_8c.html#ac478aad70b8e27e692ed478e630b8ca8", null ],
    [ "hasOneElement", "list_8c.html#a2836ef102398158b90d3500b075aec3d", null ],
    [ "newList", "list_8c.html#adc575b059f0ebefad984bce0cf1f6514", null ],
    [ "printList", "list_8c.html#a793fc22f6b0df1cef102656de7e15c9d", null ],
    [ "removeFrom", "list_8c.html#a394b759ea0a48377a5f895ee3de6d2a8", null ],
    [ "setDnsAddr", "list_8c.html#a0788e76ac54877b0352dcf1eead71622", null ]
];