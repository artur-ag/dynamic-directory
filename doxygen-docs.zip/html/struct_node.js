var struct_node =
[
    [ "c", "struct_node.html#adf0da42b816644a7278f46898b814a7d", null ],
    [ "next", "struct_node.html#aa162dd1e0693188a22b1f13b9a2a0ef0", null ]
];