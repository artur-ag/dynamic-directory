var annotated =
[
    [ "Contact", "struct_contact.html", "struct_contact" ],
    [ "Node", "struct_node.html", "struct_node" ]
];