var contact_8h =
[
    [ "Contact", "struct_contact.html", "struct_contact" ],
    [ "NAME_LEN", "contact_8h.html#a4853f6c25c8394fd57c4d99f61d5cd89", null ],
    [ "Contact", "contact_8h.html#a2d9dbffc7f547db11008c4eb9a28a3c9", null ]
];