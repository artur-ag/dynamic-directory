var searchData=
[
  ['okexpected',['okExpected',['../struct_contact.html#a6efde4258e3fa3975d3bc302f1e43d8d',1,'Contact']]],
  ['oksexpected',['oksExpected',['../globals_8c.html#ae06ee2da9ed1b2550f3330dca519812a',1,'oksExpected():&#160;globals.c'],['../globals_8h.html#ae06ee2da9ed1b2550f3330dca519812a',1,'oksExpected():&#160;globals.c']]]
];
