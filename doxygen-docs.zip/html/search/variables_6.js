var searchData=
[
  ['mydnsport',['myDnsPort',['../globals_8c.html#a7e489fe731cbea399dcf01948708c486',1,'myDnsPort():&#160;globals.c'],['../globals_8h.html#a7e489fe731cbea399dcf01948708c486',1,'myDnsPort():&#160;globals.c']]],
  ['myip',['myIP',['../globals_8c.html#a273bd63b50aa6977e43febcb2f4d3518',1,'myIP():&#160;globals.c'],['../globals_8h.html#a273bd63b50aa6977e43febcb2f4d3518',1,'myIP():&#160;globals.c']]],
  ['myname',['myName',['../globals_8c.html#ad0ccbea96f9e289b254d540802cc4df0',1,'myName():&#160;globals.c'],['../globals_8h.html#ad0ccbea96f9e289b254d540802cc4df0',1,'myName():&#160;globals.c']]],
  ['mytalkport',['myTalkPort',['../globals_8c.html#a8fe0901d911d2d25b8b80cf9fddc7bd8',1,'myTalkPort():&#160;globals.c'],['../globals_8h.html#a8fe0901d911d2d25b8b80cf9fddc7bd8',1,'myTalkPort():&#160;globals.c']]]
];
