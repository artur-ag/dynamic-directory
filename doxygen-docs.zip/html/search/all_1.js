var searchData=
[
  ['becomedns',['becomeDNS',['../server_8c.html#a96e2cbac33d799cf2f92cc7dfcacf371',1,'becomeDNS(char *buffer, struct sockaddr_in *addr, socklen_t addrLen):&#160;server.c'],['../server_8h.html#a96e2cbac33d799cf2f92cc7dfcacf371',1,'becomeDNS(char *buffer, struct sockaddr_in *addr, socklen_t addrLen):&#160;server.c']]]
];
