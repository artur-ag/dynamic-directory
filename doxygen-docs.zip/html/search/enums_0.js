var searchData=
[
  ['findmode',['FindMode',['../globals_8h.html#ab55357cbf21a8cfaeb8e63b118b39c0c',1,'globals.h']]],
  ['findstatus',['FindStatus',['../globals_8h.html#aad64cfc1afdcfdd66cd84751351519a4',1,'globals.h']]]
];
