var searchData=
[
  ['findforconnect',['FindForConnect',['../globals_8h.html#ab55357cbf21a8cfaeb8e63b118b39c0ca41de00857291e5b368b39e58c729dd26',1,'globals.h']]],
  ['findforfind',['FindForFind',['../globals_8h.html#ab55357cbf21a8cfaeb8e63b118b39c0caed8e7a3fbf2284ce7539a0433698fa5b',1,'globals.h']]]
];
