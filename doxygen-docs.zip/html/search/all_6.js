var searchData=
[
  ['get',['get',['../list_8c.html#aff4f19e720f6e0cb808e2a0af5af43cb',1,'get(Node *list, char *name):&#160;list.c'],['../list_8h.html#aff4f19e720f6e0cb808e2a0af5af43cb',1,'get(Node *list, char *name):&#160;list.c']]],
  ['getbyaddr',['getByAddr',['../list_8c.html#ac478aad70b8e27e692ed478e630b8ca8',1,'getByAddr(Node *list, struct sockaddr_in *addr, socklen_t addrlen):&#160;list.c'],['../list_8h.html#ac478aad70b8e27e692ed478e630b8ca8',1,'getByAddr(Node *list, struct sockaddr_in *addr, socklen_t addrlen):&#160;list.c']]],
  ['getcontactfrommsg',['getContactFromMsg',['../server_8c.html#a8ae651c902e257d16f57159b8c3a5296',1,'getContactFromMsg(char *message, Contact *out_contact):&#160;server.c'],['../server_8h.html#a8ae651c902e257d16f57159b8c3a5296',1,'getContactFromMsg(char *message, Contact *out_contact):&#160;server.c']]],
  ['getdefaultss',['getDefaultSS',['../main_8c.html#af77f475763a1429ffb41092489af9520',1,'main.c']]],
  ['getnameserver',['getNameServer',['../globals_8c.html#a4bb99e92aa0269c20bdc1f1c09adad61',1,'getNameServer():&#160;globals.c'],['../globals_8h.html#a4bb99e92aa0269c20bdc1f1c09adad61',1,'getNameServer():&#160;globals.c']]],
  ['getregmessage',['getRegMessage',['../commands_8c.html#a3686c0352f2b82f22ff2d76f62ba2718',1,'getRegMessage(char *buffer):&#160;commands.c'],['../commands_8h.html#a3686c0352f2b82f22ff2d76f62ba2718',1,'getRegMessage(char *buffer):&#160;commands.c']]],
  ['globals_2ec',['globals.c',['../globals_8c.html',1,'']]],
  ['globals_2eh',['globals.h',['../globals_8h.html',1,'']]]
];
