var searchData=
[
  ['c',['c',['../struct_node.html#adf0da42b816644a7278f46898b814a7d',1,'Node']]],
  ['contacts',['contacts',['../globals_8c.html#a436665f391fd410cf78813a9361531c1',1,'contacts():&#160;globals.c'],['../globals_8h.html#a436665f391fd410cf78813a9361531c1',1,'contacts():&#160;globals.c']]]
];
