var searchData=
[
  ['newlist',['newList',['../list_8c.html#adc575b059f0ebefad984bce0cf1f6514',1,'newList():&#160;list.c'],['../list_8h.html#adc575b059f0ebefad984bce0cf1f6514',1,'newList():&#160;list.c']]]
];
