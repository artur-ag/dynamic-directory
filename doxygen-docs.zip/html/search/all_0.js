var searchData=
[
  ['abortjoin',['abortJoin',['../globals_8c.html#ab528aacf1962cb5dad6a68dbcb429442',1,'abortJoin():&#160;globals.c'],['../globals_8h.html#ab528aacf1962cb5dad6a68dbcb429442',1,'abortJoin():&#160;globals.c']]],
  ['acceptcall',['acceptCall',['../server_8c.html#a1fcddbd9172248eb40f25dcdc420f00e',1,'acceptCall():&#160;server.c'],['../server_8h.html#a1fcddbd9172248eb40f25dcdc420f00e',1,'acceptCall():&#160;server.c']]],
  ['add',['add',['../list_8c.html#a11ac98f2e01e7fa68bdb69f760fe41be',1,'add(Node *list, Contact *c):&#160;list.c'],['../list_8h.html#a11ac98f2e01e7fa68bdb69f760fe41be',1,'add(Node *list, Contact *c):&#160;list.c']]]
];
