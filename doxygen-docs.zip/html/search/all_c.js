var searchData=
[
  ['name',['name',['../struct_contact.html#a4f4ce0a89bfc6e0c29787faf7de3bfcd',1,'Contact']]],
  ['name_5flen',['NAME_LEN',['../contact_8h.html#a4853f6c25c8394fd57c4d99f61d5cd89',1,'contact.h']]],
  ['nameserver',['nameServer',['../globals_8c.html#a410195894e5d9e5ee478037870529097',1,'nameServer():&#160;globals.c'],['../globals_8h.html#a410195894e5d9e5ee478037870529097',1,'nameServer():&#160;globals.c']]],
  ['nametofind',['nameToFind',['../globals_8c.html#a849ba520a0294c4598289e7744e394fb',1,'nameToFind():&#160;globals.c'],['../globals_8h.html#a3a79f9a3b7ff57562819685406c5f42e',1,'nameToFind():&#160;globals.c']]],
  ['newlist',['newList',['../list_8c.html#adc575b059f0ebefad984bce0cf1f6514',1,'newList():&#160;list.c'],['../list_8h.html#adc575b059f0ebefad984bce0cf1f6514',1,'newList():&#160;list.c']]],
  ['next',['next',['../struct_node.html#aa162dd1e0693188a22b1f13b9a2a0ef0',1,'Node']]],
  ['node',['Node',['../struct_node.html',1,'Node'],['../list_8h.html#a0466fc5f1bc9e6de776e48149b19c471',1,'Node():&#160;list.h']]],
  ['notfinding',['NotFinding',['../globals_8h.html#aad64cfc1afdcfdd66cd84751351519a4a011ce6c46ed3f4bc6ca74ee3b502303f',1,'globals.h']]],
  ['notjoined',['NotJoined',['../globals_8h.html#a66bf92a169598cb896dcb1c669406075a3f9af8ff350c8ca2697f93fec226108d',1,'globals.h']]]
];
