var searchData=
[
  ['errno',['errno',['../commands_8c.html#ad65a8842cc674e3ddf69355898c0ecbf',1,'errno():&#160;commands.c'],['../main_8c.html#ad65a8842cc674e3ddf69355898c0ecbf',1,'errno():&#160;main.c'],['../server_8c.html#ad65a8842cc674e3ddf69355898c0ecbf',1,'errno():&#160;server.c']]]
];
