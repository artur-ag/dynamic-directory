var searchData=
[
  ['talkport',['talkPort',['../struct_contact.html#ae2538c4adbf6d1ab3bdb2870db4850b5',1,'Contact']]],
  ['talkserversocket',['talkServerSocket',['../globals_8c.html#a968b2c5fbe0b2f5dbcef6459eb0449c1',1,'talkServerSocket():&#160;globals.c'],['../globals_8h.html#a968b2c5fbe0b2f5dbcef6459eb0449c1',1,'talkServerSocket():&#160;globals.c']]],
  ['talksocket',['talkSocket',['../globals_8c.html#ab8cbf40b9361e9ead7965f7553214a2c',1,'talkSocket():&#160;globals.c'],['../globals_8h.html#ab8cbf40b9361e9ead7965f7553214a2c',1,'talkSocket():&#160;globals.c']]]
];
