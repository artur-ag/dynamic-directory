var searchData=
[
  ['server_2ec',['server.c',['../server_8c.html',1,'']]],
  ['server_2eh',['server.h',['../server_8h.html',1,'']]]
];
