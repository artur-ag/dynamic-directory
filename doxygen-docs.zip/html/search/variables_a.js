var searchData=
[
  ['saaddr',['saAddr',['../globals_8c.html#a9df294c17ce9ba529ba02a75427b832c',1,'saAddr():&#160;globals.c'],['../globals_8h.html#a9df294c17ce9ba529ba02a75427b832c',1,'saAddr():&#160;globals.c']]],
  ['saip',['saIP',['../globals_8c.html#a334b9065ff9d98524f4f47ff5760ead4',1,'saIP():&#160;globals.c'],['../globals_8h.html#a334b9065ff9d98524f4f47ff5760ead4',1,'saIP():&#160;globals.c']]],
  ['saport',['saPort',['../globals_8c.html#ad0991b8bced639ebf9ac0b0a1d3ddbae',1,'saPort():&#160;globals.c'],['../globals_8h.html#ad0991b8bced639ebf9ac0b0a1d3ddbae',1,'saPort():&#160;globals.c']]]
];
