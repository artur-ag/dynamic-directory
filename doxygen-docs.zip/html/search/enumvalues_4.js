var searchData=
[
  ['searchingnewdns',['SearchingNewDns',['../globals_8h.html#a66bf92a169598cb896dcb1c669406075aff335aa9721ef8f0cc16471458cb3fca',1,'globals.h']]]
];
