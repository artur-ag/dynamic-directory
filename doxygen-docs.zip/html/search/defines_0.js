var searchData=
[
  ['name_5flen',['NAME_LEN',['../contact_8h.html#a4853f6c25c8394fd57c4d99f61d5cd89',1,'contact.h']]]
];
