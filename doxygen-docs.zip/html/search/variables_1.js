var searchData=
[
  ['dnsaddr',['dnsAddr',['../struct_contact.html#a3e5b283d7a0d10c7fccb0814e983a83a',1,'Contact']]],
  ['dnsport',['dnsPort',['../struct_contact.html#aea2f9dd57472d7779591f1b1e97253a3',1,'Contact']]],
  ['dnssocket',['dnsSocket',['../globals_8c.html#a2a7e0885d0b5749e64e1d66bb4d4be10',1,'dnsSocket():&#160;globals.c'],['../globals_8h.html#a2a7e0885d0b5749e64e1d66bb4d4be10',1,'dnsSocket():&#160;globals.c']]]
];
