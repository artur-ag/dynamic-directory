var searchData=
[
  ['joinstatus',['joinStatus',['../globals_8c.html#a347e0d1642069ab73d2c9e5e853515f9',1,'joinStatus():&#160;globals.c'],['../globals_8h.html#a347e0d1642069ab73d2c9e5e853515f9',1,'joinStatus():&#160;globals.c']]]
];
