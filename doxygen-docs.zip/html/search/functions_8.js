var searchData=
[
  ['isserver',['isServer',['../commands_8c.html#a642dc09bc041fe347f35ea51713a5562',1,'isServer():&#160;commands.c'],['../commands_8h.html#a642dc09bc041fe347f35ea51713a5562',1,'isServer():&#160;commands.c']]]
];
