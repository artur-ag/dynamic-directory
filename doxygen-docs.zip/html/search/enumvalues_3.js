var searchData=
[
  ['notfinding',['NotFinding',['../globals_8h.html#aad64cfc1afdcfdd66cd84751351519a4a011ce6c46ed3f4bc6ca74ee3b502303f',1,'globals.h']]],
  ['notjoined',['NotJoined',['../globals_8h.html#a66bf92a169598cb896dcb1c669406075a3f9af8ff350c8ca2697f93fec226108d',1,'globals.h']]]
];
