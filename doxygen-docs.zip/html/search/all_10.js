var searchData=
[
  ['saaddr',['saAddr',['../globals_8c.html#a9df294c17ce9ba529ba02a75427b832c',1,'saAddr():&#160;globals.c'],['../globals_8h.html#a9df294c17ce9ba529ba02a75427b832c',1,'saAddr():&#160;globals.c']]],
  ['saip',['saIP',['../globals_8c.html#a334b9065ff9d98524f4f47ff5760ead4',1,'saIP():&#160;globals.c'],['../globals_8h.html#a334b9065ff9d98524f4f47ff5760ead4',1,'saIP():&#160;globals.c']]],
  ['saport',['saPort',['../globals_8c.html#ad0991b8bced639ebf9ac0b0a1d3ddbae',1,'saPort():&#160;globals.c'],['../globals_8h.html#ad0991b8bced639ebf9ac0b0a1d3ddbae',1,'saPort():&#160;globals.c']]],
  ['searchingnewdns',['SearchingNewDns',['../globals_8h.html#a66bf92a169598cb896dcb1c669406075aff335aa9721ef8f0cc16471458cb3fca',1,'globals.h']]],
  ['sendmessage',['sendMessage',['../commands_8c.html#a8bbf464384e4ff787fc006dcc38ccd6e',1,'sendMessage(char *message):&#160;commands.c'],['../commands_8h.html#a8bbf464384e4ff787fc006dcc38ccd6e',1,'sendMessage(char *message):&#160;commands.c']]],
  ['sendrawmessage',['sendRawMessage',['../commands_8c.html#aa50a95001a98c33cd0dbc0b3080f6aa0',1,'sendRawMessage(char *message):&#160;commands.c'],['../commands_8h.html#aa50a95001a98c33cd0dbc0b3080f6aa0',1,'sendRawMessage(char *message):&#160;commands.c']]],
  ['server_2ec',['server.c',['../server_8c.html',1,'']]],
  ['server_2eh',['server.h',['../server_8h.html',1,'']]],
  ['setdnsaddr',['setDnsAddr',['../list_8c.html#a0788e76ac54877b0352dcf1eead71622',1,'setDnsAddr(Contact *c):&#160;list.c'],['../list_8h.html#a0788e76ac54877b0352dcf1eead71622',1,'setDnsAddr(Contact *c):&#160;list.c']]],
  ['siginthandler',['sigintHandler',['../main_8c.html#a7b20230d2aa1f4b6f30b4f5ce9820bac',1,'main.c']]],
  ['startchatcall',['startChatCall',['../server_8c.html#a7351a900efbe3b9ef812e2a520826044',1,'startChatCall(char *name, struct sockaddr_in peerAddr):&#160;server.c'],['../server_8h.html#a7351a900efbe3b9ef812e2a520826044',1,'startChatCall(char *name, struct sockaddr_in peerAddr):&#160;server.c']]]
];
