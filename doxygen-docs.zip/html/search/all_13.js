var searchData=
[
  ['verbose',['verbose',['../globals_8c.html#a0b2caeb4b6f130be43e5a2f0267dd453',1,'verbose():&#160;globals.c'],['../globals_8h.html#a0b2caeb4b6f130be43e5a2f0267dd453',1,'verbose():&#160;globals.c']]]
];
