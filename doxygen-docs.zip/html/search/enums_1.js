var searchData=
[
  ['joinstatus',['JoinStatus',['../globals_8h.html#a66bf92a169598cb896dcb1c669406075',1,'globals.h']]]
];
