var searchData=
[
  ['node',['Node',['../list_8h.html#a0466fc5f1bc9e6de776e48149b19c471',1,'list.h']]]
];
