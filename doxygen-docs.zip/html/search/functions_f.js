var searchData=
[
  ['sendmessage',['sendMessage',['../commands_8c.html#a8bbf464384e4ff787fc006dcc38ccd6e',1,'sendMessage(char *message):&#160;commands.c'],['../commands_8h.html#a8bbf464384e4ff787fc006dcc38ccd6e',1,'sendMessage(char *message):&#160;commands.c']]],
  ['sendrawmessage',['sendRawMessage',['../commands_8c.html#aa50a95001a98c33cd0dbc0b3080f6aa0',1,'sendRawMessage(char *message):&#160;commands.c'],['../commands_8h.html#aa50a95001a98c33cd0dbc0b3080f6aa0',1,'sendRawMessage(char *message):&#160;commands.c']]],
  ['setdnsaddr',['setDnsAddr',['../list_8c.html#a0788e76ac54877b0352dcf1eead71622',1,'setDnsAddr(Contact *c):&#160;list.c'],['../list_8h.html#a0788e76ac54877b0352dcf1eead71622',1,'setDnsAddr(Contact *c):&#160;list.c']]],
  ['siginthandler',['sigintHandler',['../main_8c.html#a7b20230d2aa1f4b6f30b4f5ce9820bac',1,'main.c']]],
  ['startchatcall',['startChatCall',['../server_8c.html#a7351a900efbe3b9ef812e2a520826044',1,'startChatCall(char *name, struct sockaddr_in peerAddr):&#160;server.c'],['../server_8h.html#a7351a900efbe3b9ef812e2a520826044',1,'startChatCall(char *name, struct sockaddr_in peerAddr):&#160;server.c']]]
];
