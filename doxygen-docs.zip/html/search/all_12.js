var searchData=
[
  ['unregisteruser',['unregisterUser',['../server_8c.html#ac62c77340a5f0aecc356123b82aeeb18',1,'unregisterUser(char *buffer, struct sockaddr_in *addr, socklen_t addrLen):&#160;server.c'],['../server_8h.html#ae07e9eb35e2cf804c3f0d67af2ca4e0f',1,'unregisterUser(char *userUNR, struct sockaddr_in *addr, socklen_t addrLen):&#160;server.c']]]
];
