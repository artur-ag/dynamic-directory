var searchData=
[
  ['receivelist',['receiveList',['../server_8c.html#af81fba6e73a20935331ed8602722eccf',1,'receiveList(char *buffer):&#160;server.c'],['../server_8h.html#a45630fa5969b9ce97e10d7f77cdf63af',1,'receiveList():&#160;server.h']]],
  ['receivemessage',['receiveMessage',['../server_8c.html#a31876151b63941ae68830fd1527bc473',1,'receiveMessage(char *buffer):&#160;server.c'],['../server_8h.html#a31876151b63941ae68830fd1527bc473',1,'receiveMessage(char *buffer):&#160;server.c']]],
  ['registeratdns',['registerAtDns',['../commands_8h.html#aca56a0df2458e7b9e80d89decb947a49',1,'commands.h']]],
  ['registernewuser',['registerNewUser',['../server_8c.html#a9538b34b4d35b859e063fa9ba4f89a40',1,'registerNewUser(char *newUserREG, struct sockaddr_in *addr, socklen_t addrLen):&#160;server.c'],['../server_8h.html#a9538b34b4d35b859e063fa9ba4f89a40',1,'registerNewUser(char *newUserREG, struct sockaddr_in *addr, socklen_t addrLen):&#160;server.c']]],
  ['removefrom',['removeFrom',['../list_8c.html#a394b759ea0a48377a5f895ee3de6d2a8',1,'removeFrom(Node *list, char *name):&#160;list.c'],['../list_8h.html#a394b759ea0a48377a5f895ee3de6d2a8',1,'removeFrom(Node *list, char *name):&#160;list.c']]],
  ['replytoquery',['replyToQuery',['../server_8c.html#a738426b3b9f030bd02263090091eb5fc',1,'replyToQuery(char *buffer, struct sockaddr_in *addr, socklen_t addrLen):&#160;server.c'],['../server_8h.html#a958759938e44eef51de14017780e6488',1,'replyToQuery(char *argument, struct sockaddr_in *addr, socklen_t addrLen):&#160;server.c']]],
  ['rickroll',['rickroll',['../commands_8c.html#a0b93e6a3ac7105977d863c5bd940f8fb',1,'rickroll():&#160;commands.c'],['../commands_8h.html#a0b93e6a3ac7105977d863c5bd940f8fb',1,'rickroll():&#160;commands.c']]]
];
