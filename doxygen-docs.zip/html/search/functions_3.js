var searchData=
[
  ['disconnect',['disconnect',['../commands_8c.html#a960705de531a20389fb29928d43258c3',1,'disconnect():&#160;commands.c'],['../commands_8h.html#a960705de531a20389fb29928d43258c3',1,'disconnect():&#160;commands.c']]]
];
