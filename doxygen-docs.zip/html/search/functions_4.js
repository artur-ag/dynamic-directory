var searchData=
[
  ['emptylist',['emptyList',['../list_8c.html#abd0aee2995c30006ca350371a713dee7',1,'emptyList(Node *list):&#160;list.c'],['../list_8h.html#abd0aee2995c30006ca350371a713dee7',1,'emptyList(Node *list):&#160;list.c']]]
];
